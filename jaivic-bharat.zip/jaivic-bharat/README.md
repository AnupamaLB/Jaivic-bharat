# 🌱 Jaivic Bharat - Nature-Aligned Living Platform

A comprehensive website for the Jaivic Bharat movement showcasing nature-aligned living initiatives across India.

## 🚀 Live Deployment
- **Vercel URL:** https://jaivic-bharat.vercel.app
- **GitHub Repository:** [Your GitHub repo link]

## 📁 Project Structure